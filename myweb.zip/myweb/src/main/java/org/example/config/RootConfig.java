package org.example.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;
//x_root-context.xml 을 대신할 파일

@Configuration
@MapperScan(basePackages = "org.example.repersitoty") // 여러개는 스캔s 사용
public class RootConfig {

    @Bean //CP : HikariCP
    public HikariConfig hikariConfig(){
        HikariConfig config = new HikariConfig();
        config.setDriverClassName("com.mysql.cj.jdbc.Driver");
        config.setJdbcUrl("jdbc:mysql://localhost:3306/ai");
        config.setUsername("root");
        config.setPassword("12345");
        return  config;
    }

    @Bean // Hikari 데이터 소스
    public DataSource dataSource(){
        // hikariConfig()를 호출해서 사용
        return  new HikariDataSource( hikariConfig() ); //Connection Pool
    }

    @Bean // mapper.xml 찾기
    public SqlSessionFactory sqlSessionFactory(DataSource dataSource) throws  Exception{
        SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
        sqlSessionFactoryBean.setDataSource(dataSource);
        sqlSessionFactoryBean.setMapperLocations(
                new PathMatchingResourcePatternResolver().getResources("classpath:mybatis-config/mapper/**.xml"));
        return  sqlSessionFactoryBean.getObject(); // SqlSessionFactory
    }

}


