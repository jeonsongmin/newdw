package org.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.DefaultServletHandlerConfigurer;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

//x_servlet-context.xml 대체기능
@Configuration
@EnableWebMvc // <annotation-driven/> 대체
@ComponentScan(basePackages = {"org.example.controller", "org.example.service"}) // POJO 대체
public class ServletConfig implements WebMvcConfigurer {

    @Override // 재정의 됨
    public void configureDefaultServletHandling(DefaultServletHandlerConfigurer configurer) {
        configurer.enable(); // 핸들러 맵핑을 활성화
    }

    @Bean // 스프링 컨테이너에 객체가 생성(메소드가 호출됨)
    public ViewResolver viewResolver(){
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".jsp");
        return  resolver;
    }
}
