package org.example.controller;

import org.example.entity.Board;
import org.example.repersitoty.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletException;
import java.util.List;

@Controller // @RestController (JSON 데이터 처리할때 사용)
// servlet-context에서 컨트롤러임을 식별. -> POJO로 인식함

public class BoardController {
// POJO -> new BoardController() -> Spring Controller -> DI(의존성 주입)

    @Autowired // 연결된 메소드을 보고 연결
    private  BoardMapper mapper;

    //http://localhost:8081/myweb/spring
    @RequestMapping("/spring")
    public String index(){
        System.out.println("spring방문");
        return "template"; // WEB-INF/views/template.jsp
    }

    // 리스트 가져오기 요청받기
    @RequestMapping("/list") // Hendler Mapping
    public String list(Model model){
        List<Board> list = mapper.boardList();

        // 객체바인딩
        model.addAttribute("list", list);
        // view의 논리적인 이름 리턴 -> 프론트컨트롤러에게 리턴

        return "board/list";
    }


    // 등록하기 요청
    @GetMapping("/register")
    public String registerGet(){
        return "board/register"; // -> register.jsp 이동
    }

    @PostMapping("/register") // 넘어오는 데이터 : title, content, writer (JSON 아님)
    public String registerPost(Board board) throws Exception{ // 파라메터 수집


        int cnt = mapper.boardInsert(board);
        if(cnt > 0){
            return "redirect:/list"; // 등록성공 -> 다시 리스트 페이지로 이동(redirect)
        } else {
            throw new ServletException("error");
        }
    }

    @GetMapping("/get/{num}")
    public String get(@PathVariable Long num, Model model){
        Board board = mapper.getByNum(num);
        // 이클립스에선 세션으로 jsp에 넘기듯 model에 넘긴다는 뜻임
        model.addAttribute("board", board);
        //get.jsp forward
        return "board/get";
    }

    @GetMapping("/remove/{num}")
    public String remove(@PathVariable Long num){
        mapper.boardDelete(num);
        return "redirect:/list";
    }

    @GetMapping("/update/{num}")
    public String updateGet(@PathVariable Long num, Model model){
      Board board =  mapper.getByNum(num);
      model.addAttribute("board", board);
      return "board/update"; //update.jsp( <- get.jsp)
    }

    @PostMapping("/update")
    public String updatePost(Board board){ // num, title, content
        mapper.boardUpdate(board);
        return "redirect:/get/" + board.getNum(); // 수정한 상세페이지 이동
    }
}
