package org.example.controller;

import org.example.entity.Board;
import org.example.repersitoty.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController // @RestController (JSON 데이터 처리할때 사용)
@RequestMapping("/api")
public class BoardRestController {
// POJO -> new BoardController() -> Spring Controller -> DI(의존성 주입)

    @Autowired // 연결된 메소드을 보고 연결
    private  BoardMapper mapper;

    //http://localhost:8081/myweb/rspring
    // GET : http://localhost:8081/myweb/api/board : 게시판 전체리스트
    @GetMapping("/board")
    public List<Board> index(){
        return mapper.boardList(); // WEB-INF/views/template.jsp
    }

    // 리스트 가져오기 요청받기
    @GetMapping("/rlist") // Hendler Mapping
    public List<Board> list(Model model){
        List<Board> list = mapper.boardList();
        return list; // list ->  JSON Array : [{ },{ }...];
    }

    // 등록하기 요청
    // Post : http://localhost:8081/myweb/api/board : 게시판 등록하기
    // requset parameter : title, content, writer = JSON
    @PostMapping("/board")
    public int register(@RequestBody Board board){ // 자동으로 파라메터가 수집
        System.out.println(board);
        return mapper.boardInsert(board);
    }

    // DELETE : http://localhost:8081/myweb/api/board/{num} : 게시판 삭제하기
    // request parameter : num
    @DeleteMapping("/board/{num}")
    public int boardDelete(@PathVariable Long num){
        return mapper.boardDelete(num);
    }


    // getBynum(Long num)
    // get : http://localhost:8081/myweb/api/board/{num} : 게시판 상세보기
    @GetMapping("/board/{num}")
    public ResponseEntity<?> getByNum(@PathVariable Long num){
        Board board = mapper.getByNum(num);
        // 성공/실패에 대한 예외처리
        if(board != null){
            return new ResponseEntity<>(board,HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Fail..", HttpStatus.BAD_REQUEST);
        }
    }

    // boardUpdate(Long num, Board board)
    @PutMapping("/board/{num}")
    public ResponseEntity<?> boardUpdate(@PathVariable Long num, @RequestBody Board board){
        board.setNum(num); //
        return new ResponseEntity<>(mapper.boardUpdate(board),HttpStatus.OK);
    }

}
