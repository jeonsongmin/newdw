package org.example.controller;

import org.example.entity.Member;
import org.example.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    private LoginService service;

    @PostMapping("/login")
    public String login(Member member, HttpSession session){
        Member dbmember = service.login(member);
        // null 이면 실패! / not null 이면 성공!
        if(dbmember != null){ //성공시
            // 데이터를 꺼내오는 순서(아래)
            // PageContext, HttpServletRequest, HttpSession, ServletContext
            session.setAttribute("member", dbmember);
        }
        // 다시 시작페이지로 전환
        return  "redirect:/list";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session){
        // 세션을 무효화 시킴
        // -> 로그아웃 방법은 여러가지
        // (강제[invalidate()], 세션 타임아웃(1800s), 브라우저 종료, 서버 종료)
        session.invalidate();
        return "redirect:/list"; // 로그아웃된 화면으로
    }
}
