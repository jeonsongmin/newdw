package org.example.repersitoty;

import org.example.entity.Board;

import java.util.List;

public interface BoardMapper { // public class SqlSessionFactory implements BoardMapper
    // SqlSessionFactory

    // 전체 게시물을 가져오는 기능 (TDD)
    public List<Board> boardList();
    public int boardInsert(Board board);
    public int boardDelete(Long num);

    public Board getByNum(Long num);

    public int boardUpdate(Board board); // 번호가 식별자로 제목과 내용을 변경
}
