package org.example.repersitoty;

import org.example.entity.Board;
import org.example.entity.Member;

import java.util.List;

public interface MemberMapper { // public class SqlSessionFactory implements MemberMapper
    // SqlSessionFactory

    public Member login(Member member);
}
