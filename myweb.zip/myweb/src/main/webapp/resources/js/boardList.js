function boardList(){
    // 서버통신 : ajax -> jQuery(X)
    // fetch().then().then()
    fetch("http://localhost:8081/myweb/api/board")

    // 위 경로 결과를 then()이 받는다.
    .then(function(res){ // res -> JSON String
        // ok는 이메일을 가르키는 단어
        if(!res.ok){
            throw new Error("Network response was not ok");
        }
        console.log(res);
        return res.json(); // JavaScript Object 변경
    })

    // res.json()를 받아서 동적뷰를 만들어 낸다.
    .then(function(boards){
        console.log(boards);
        let boardListTable = document.getElementById("boardList");
        let tbody = boardListTable.querySelector("tbody");

        tbody.innerHTML = '';  // 반복 결과 초기화
        boards.forEach(function(board){
            let tr = document.createElement("tr"); // <tr></tr> 태그 생성
            // tr 태그 안에 td 태그 생성
            tr.innerHTML =  '<td>' + board.num + '</td>' +
                            '<td><a href="/myweb/rest/get/' + board.num + '">' + board.title + '</a></td>' +
                            '<td>' + board.writer + '</td>' +
                            '<td>' + board.indate + '</td>' +
                            '<td>' + board.cnt + '</td>' ;
            tbody.append(tr);
        });
    });
}
